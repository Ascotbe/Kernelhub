# COMahawk
**Privilege Escalation: Weaponizing CVE-2019-1405 and CVE-2019-1322**

## Video Demo
https://vimeo.com/373051209

## Usage

### Compile or Download from Release (https://github.com/apt69/COMahawk/releases)

1. Run COMahawk.exe
2. ???
3. Hopefully profit

or

1. COMahawk.exe "custom command to run" (ie. COMahawk.exe "net user /add test123 lol123 &")
2. ???
3. Hopefully profit

## Concerns
**MSDN mentioned that only 1803 to 1903 is vulnerable to CVE-2019-1322. If it doesn't work, maybe it was patched.**

However, it is confirmed that my 1903 does indeed have this bug so maybe it was introduced somewhere inbetween. YMMV.

Also, since you are executing from a service - you most likely cannot spawn any Window hence all command will be "GUI-less". Maybe different session? Idk, it is too late and I am tired haha.

## Credits:
https://twitter.com/leoloobeek for helping me even when he doesn't even have a laptop

https://twitter.com/TomahawkApt69 for being the mental support and motivation

and most of all:

https://www.nccgroup.trust/uk/about-us/newsroom-and-events/blogs/2019/november/cve-2019-1405-and-cve-2019-1322-elevation-to-system-via-the-upnp-device-host-service-and-the-update-orchestrator-service/

for discovering and publishing the write up. 100% of the credit goes here.
